package pp.block2.cc.ref;


import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.Token;
import pp.block2.cc.*;
import pp.block2.cc.ll.Grammar;
import pp.block2.cc.ll.LLCalc;
import pp.block2.cc.ll.MyLLCalc;
import pp.block2.cc.ll.Rule;

import java.util.*;

/**
 * Generic table-driven LL(1)-parser.
 */
public class GenericLLParserRef implements Parser {
	private final Grammar g;
	private final LLCalc calc;
//	private Rule errorRule = new Rule(new Error("Error"), new Error("Error"));
	private List<? extends Token> tokens = new ArrayList<>();
	private int index;
	private List<Symbol> stack = new ArrayList<>();
	private Map<Integer, Integer> indexList = new HashMap<>();
	/**
	 * Map from non-terminals to lists of rules indexed by token type.
	 */
	private Map<NonTerm, List<Rule>> ll1Table;

	// fill in

	public GenericLLParserRef(Grammar g) {
		this.g = g;
		this.calc = new MyLLCalc(g); // here use your own class
	}

	private Map<NonTerm, List<Rule>> getLL1Table() {
		if (ll1Table == null) {
			ll1Table = calcLL1Table();
		}
		return ll1Table;
	}

	/**
	 * Constructs the {@link #ll1Table}.
	 */
	private Map<NonTerm, List<Rule>> calcLL1Table() {
		Map<Rule, Set<Term>> firstp = calc.getFirstp();
		Map<NonTerm, List<Rule>> result = new HashMap<>();

		for (NonTerm a : g.getNonterminals()) {
			List<Rule> list = new ArrayList<>();
			int i = 0;
			for (Term w : g.getTerminals()) {
				indexList.put(w.getTokenType(), i);
//				list.add(errorRule);
				i++;
			}

			for (Rule r : getAllRules(a)) {
				for (Term w : firstp.get(r)) {
					list.set(indexList.get(w.getTokenType()), r);
				}
				if (firstp.get(r).contains(Symbol.EOF)) {
					list.set(indexList.get(Symbol.EOF), r);
				}
			}
			result.put(a, list);
		}
		return result;
	}

	@Override
	public AST parse(Lexer lexer) throws ParseException {
		tokens = lexer.getAllTokens();
		index = 0;
		return parseGeneric();
	}

	public AST parseGeneric() throws ParseException {
		AST result = new AST(g.getStart());
		Token next = tokens.get(index);
		stack = new ArrayList<>();
		stack.add(Symbol.EOF);
		stack.add(g.getStart());
		Symbol focus = getLast();
		while (true) {
			if (focus.equals(Symbol.EOF) && next.equals(Symbol.EOF)) {
				break;
			} else if (focus instanceof Term || focus.equals(Symbol.EOF)) {
				if (((Term) focus).getTokenType() == next.getType()) {
					result.addChild(parseTerm((Term) focus, next));
					index++;
					if (tokens.size() <= index)
						break;
					next = tokens.get(index);
				} else {
					throw unparsable();
				}
			} else if (!focus.equals(g.getStart())) {
				result.addChild(parseNonTerm((NonTerm) focus));
				index++;
				if (tokens.size() <= index)
					break;
				next = tokens.get(index);
			} else {
				pop();
				Rule r = getLL1Table().get(focus).get(indexList.get(next.getType()));

				List<Symbol> rhs = r.getRHS();
				for (int i = rhs.size() - 1; i >= 0; i--) {
					if (!rhs.get(i).equals(Symbol.EMPTY)) {
						stack.add(rhs.get(i));
					}
				}
			}
			focus = getLast();
		}
		if (stack.size() != 1 || !stack.contains(Symbol.EOF)) {
			throw unparsable();
		}
		System.out.println(result);
		return result;
	}

	private AST parseTerm(Term term, Token token) {
		AST result = new AST(term, token);
		pop();
		return result;
	}

	private AST parseNonTerm(NonTerm nt) throws ParseException {
		AST result = new AST(nt);
		Symbol focus = getLast();
		if (focus.equals(Symbol.EOF))
			return result;
		if (focus instanceof Error)
			throw unparsable();
		pop();
		Token next = tokens.get(index);
		Rule r = getLL1Table().get(focus).get(indexList.get(next.getType()));

		List<Symbol> rhs = r.getRHS();
		for (int i = rhs.size() - 1; i >= 0; i--) {
			if (!rhs.get(i).equals(Symbol.EMPTY)) {
				stack.add(rhs.get(i));
			}
		}

		Symbol lastFocus = focus;
		focus = getLast();

		if (focus instanceof Term) {
			result.addChild(parseTerm((Term) focus, next));
		} else {
			result.addChild(parseNonTerm((NonTerm) focus));
			index++;
			result.addChild(parseNonTerm((NonTerm) lastFocus));
		}
		return result;
	}

	private Symbol getLast() {
		return stack.get(stack.size() - 1);
	}

	private void pop() {
		Symbol top = stack.get(stack.size() - 1);
		stack.remove(top);
	}

	private void printTable() {
		Map<NonTerm, List<Rule>> map = getLL1Table();

		for (Term t : g.getTerminals()) {
			System.out.print(t + " | ");
		}

		System.out.println();

		for (NonTerm n : map.keySet()) {
			System.out.print(n + ": ");
			for (Rule r : map.get(n)) {
				System.out.print(r + " | ");
			}
			System.out.print(System.lineSeparator());
		}
	}

	private void printTable(Map<NonTerm, List<Rule>> map) {

		for (NonTerm n : map.keySet()) {
			System.out.print(n + ": ");
			for (Rule r : map.get(n)) {
				System.out.print(r + " | ");
			}
			System.out.print(System.lineSeparator());
		}
	}

	private List<Rule> getAllRules(NonTerm a) {
		List<Rule> rules = g.getRules();
		List<Rule> result = new ArrayList<>();
		for (Rule r : rules) {
			if (r.getLHS().equals(a))
				result.add(r);
		}
		return result;
	}

	private ParseException unparsable() {
		System.out.println("Unparsable");
		return new ParseException(String.format("Nope @ "));
	}
}
