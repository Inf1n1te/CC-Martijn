package pp.block2.cc;

public class ParseException extends Exception {
	public ParseException() {
		// empty
	}

	public ParseException(String message) {
		super(message);
	}
}
